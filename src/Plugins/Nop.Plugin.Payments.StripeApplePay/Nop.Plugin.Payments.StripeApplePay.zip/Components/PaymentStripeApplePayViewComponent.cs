﻿using System;
using Microsoft.AspNetCore.Mvc;
using Nop.Web.Framework.Components;

namespace Nop.Plugin.Payments.StripeApplePay.Components
{
    [ViewComponent(Name = StripeApplePayPaymentDefaults.ViewComponentName)]
    public class PaymentStripeApplePayViewComponent : NopViewComponent
    {
        public PaymentStripeApplePayViewComponent()
        {

        }
        
        public IViewComponentResult Invoke()
        {
            return View("~/Plugins/Nop.Plugin.Payments.PaymentStripeApplePay/Views/PaymentInfo.cshtml");

        }
        
    }
}
